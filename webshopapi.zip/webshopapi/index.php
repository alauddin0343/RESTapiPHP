<?php
	// if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
	// 	$uri = 'https://';
	// } else {
	// 	$uri = 'http://';
	// }
	// $uri .= $_SERVER['HTTP_HOST'];
	// header('Location: '.$uri.'/');
	// exit;

$cart = 'a:9:{s:4:"cart";s:506:"a:1:{s:32:"dfad886182f41d111e203a342fb1da7b";a:11:{s:3:"key";s:32:"dfad886182f41d111e203a342fb1da7b";s:10:"product_id";i:227747;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:76.719999999999998863131622783839702606201171875;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:76.719999999999998863131622783839702606201171875;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:405:"a:15:{s:8:"subtotal";s:5:"76.72";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:4:"0.00";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:5:"76.72";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:4:"0.00";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:5:"76.72";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:508:"a:1:{s:32:"dfad886182f41d111e203a342fb1da7b";a:11:{s:3:"key";s:32:"dfad886182f41d111e203a342fb1da7b";s:10:"product_id";i:227747;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:38.3599999999999994315658113919198513031005859375;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:38.3599999999999994315658113919198513031005859375;s:8:"line_tax";i:0;}}";s:10:"wc_notices";N;s:8:"customer";s:782:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:6:"347347";s:4:"city";s:7:"karachi";s:9:"address_1";s:9:"test test";s:7:"address";s:9:"test test";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"PK";s:17:"shipping_postcode";s:6:"347347";s:13:"shipping_city";s:7:"karachi";s:18:"shipping_address_1";s:9:"test test";s:16:"shipping_address";s:9:"test test";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"PK";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:4:"test";s:9:"last_name";s:4:"test";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:16:"estset@gmail.com";s:19:"shipping_first_name";s:4:"test";s:18:"shipping_last_name";s:4:"test";s:16:"shipping_company";s:0:"";}";s:21:"chosen_payment_method";s:6:"cheque";}';

echo json_decode($cart);
?>
